'use strict'

const AWS = require('aws-sdk')

AWS.config.update({
    region: 'us-east-1',
    accessKeyId: 'accessKeyId',
    secretAccessKey: 'secreAccessKey',
})

const sns = new AWS.SNS({ apiVersion: '2010-03-31' })

const dynamoDb = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1',
    apiVersion: '2012-08-10',
})

const s3 = new AWS.S3()

module.exports.createOrder = async(event) => {
    const { sku, productName, quantity } = JSON.parse(event.body)

    if (!sku || !productName || !quantity) {
        throw new Error('please specify all items in an order')
    }

    const correlationId = Math.random().toString(36).substring(2, 15)

    const order = {
        sku: sku,
        productName: productName,
        quantity: quantity,
        correlation_id: correlationId,
    }

    const params = {
        Message: JSON.stringify(order),
        TopicArn: 'arn:aws:sns:us-east-1:115318318205:SCC-project-remake',
    }

    await sns.publish(params).promise()

    return {
        statusCode: 200,
        body: JSON.stringify({
            correlation_id: correlationId,
        }),
    }
}

module.exports.updateOrder = async(event) => {
    const orderId = event.pathParameters.orderId
    const { sku, productName, quantity, correlationId } = JSON.parse(event.body)

    let data
    data = await dynamoDb
        .get({
            TableName: 'SCC-project-remake',
            Key: {
                orderId: orderId,
            },
        })
        .promise()

    if (!data.Item) {
        throw new Error('Not an entry in the database')
    }

    const updatedOrder = {
        orderId: orderId,
        sku: sku,
        productName: productName,
        quantity: quantity,
        correlation_id: correlationId,
    }

    const params = {
        Message: JSON.stringify(updatedOrder),
        TopicArn: 'arn:aws:sns:us-east-1:115318318205:SCC-project-remake',
    }

    await sns.publish(params).promise()

    return {
        statusCode: 200,
        body: JSON.stringify(updatedOrder),
    }
}

module.exports.processOrder = async(event) => {
    for (const { body }
        of event && event.Records) {
        try {
            const data = JSON.parse(body)
            const message = JSON.parse(data.Message || body)

            const { sku, productName, quantity, correlation_id } = message

            let orderId
            if (!message.orderId) {
                orderId = Math.random().toString(36).substring(2, 15)

                await dynamoDb
                    .put({
                        TableName: 'SCC-project-remake',
                        Item: {
                            orderId: orderId,
                            sku: sku,
                            productName: productName,
                            quantity: quantity,
                            correlationId: correlation_id,
                        },
                    })
                    .promise()
            } else {
                orderId = message.orderId

                const orderMessage = {
                    sku: message.sku,
                    productName: message.productName,
                    quantity: message.quantity,
                    correlationId: message.correlation_id,
                }

                let updateExpression = 'set'
                let ExpressionAttributeNames = {}
                let ExpressionAttributeValues = {}
                for (const property in orderMessage) {
                    if (
                        orderMessage[property] !== null &&
                        orderMessage[property] !== undefined
                    ) {
                        updateExpression += ` #${property} = :${property} ,`
                        ExpressionAttributeNames['#' + property] = property
                        ExpressionAttributeValues[':' + property] = orderMessage[property]
                    }
                }

                updateExpression = updateExpression.slice(0, -1)

                try {
                    const updated = await dynamoDb
                        .update({
                            TableName: 'SCC-project-remake',
                            Key: {
                                orderId: orderId,
                            },
                            UpdateExpression: updateExpression,
                            ExpressionAttributeNames: ExpressionAttributeNames,
                            ExpressionAttributeValues: ExpressionAttributeValues,
                        })
                        .promise()
                } catch (e) {
                    console.log(e)
                }
            }

            await s3
                .putObject({
                    Bucket: 'scc-project-remake',
                    Key: `${correlation_id}-${new Date()
            .toLocaleString()
            .replaceAll('/', '-')
            .replace(', ', '-')}`,
                    Body: JSON.stringify({
                        orderId: orderId,
                        sku: sku,
                        productName: productName,
                        quantity: quantity,
                        correlation_id: correlation_id,
                    }),
                    ContentType: 'application/json',
                })
                .promise()

            return {
                status: 200,
                message: `successfully processed order: ${message.productName}`,
            }
        } catch (e) {
            console.log('[processOrder Error] error:', JSON.stringify(e))
            throw e
        }
    }
}

module.exports.getOrderById = async(event) => {
    const Id = event.pathParameters.Id

    let data
    data = await dynamoDb
        .get({
            TableName: 'SCC-project-remake',
            Key: {
                orderId: Id,
            },
        })
        .promise()

    if (!data.Item) {
        data = await dynamoDb
            .scan({
                TableName: 'SCC-project-remake',
                FilterExpression: 'correlationId = :correlationId',
                ExpressionAttributeValues: {
                    ':correlationId': Id,
                },
            })
            .promise()

        if (!data.Items[0]) {
            throw new Error('this order does not exist')
        }

        return {
            statusCode: 200,
            body: JSON.stringify({
                data: {
                    ...data.Items[0],
                },
            }),
        }
    }

    return {
        statusCode: 200,
        body: JSON.stringify({
            data: {
                ...data.Item,
            },
        }),
    }
}